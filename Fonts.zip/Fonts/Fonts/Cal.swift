//
//  Cal.swift
//  Fonts
//
//  Created by Chan Choon Hee on 10/02/2017.
//  Copyright © 2017 Chan Choon Hee. All rights reserved.
//
import UIKit
import Foundation
var aIACondMedium16 = UIFont(name: "AIAEverestCondensedMedium", size: 16)
var aIACondMedium20 = UIFont(name: "AIAEverestCondensedMedium", size: 20)
var aIACondMedium26 = UIFont(name: "AIAEverestCondensedMedium", size: 26)
var arial9 = UIFont(name: "ArialMT", size: 9)
var arial10 = UIFont(name: "ArialMT", size: 10)
var arial12 = UIFont(name: "ArialMT", size: 12)
var arial13 = UIFont(name: "ArialMT", size: 13)
var arial14 = UIFont(name: "ArialMT", size: 14)
var arial60 = UIFont(name: "ArialMT", size: 60)
var arialBold12 = UIFont(name: "Arial-BoldMT", size: 12)
var arialBold16 = UIFont(name: "Arial-BoldMT", size: 16)
