//
//  EnumPlist.swift
//  Fonts
//
//  Created by J on 2/20/17.
//  Copyright © 2017 Chan Choon Hee. All rights reserved.
//

import Foundation
    
    enum colors : String{
        case B3 = "B3"
        case B4 = "B4"
        case B5 = "B5"
        case B6 = "B6"
        case P1 = "P1"
        case P2 = "P2"
        case S1 = "S1"
        case S2 = "S2"
        case S3 = "S3"
        case S5 = "S5"
        case S6 = "S6"
        case U4 = "U4"
        case AIARed = "AIARed"
        case Grey = "Grey"
        case Citrus = "Citrus"
        case Citrus80 = "Citrus80"
        case Citrus60 = "Citrus60"
        case Citrus40 = "Citrus40"
        case Citrus20 = "Citrus20"
        case Lime = "Lime"
        case Lime80 = "Lime80"
        case Lime60 = "Lime60"
        case Lime40 = "Lime40"
        case Lime20 = "Lime20"
        case Plum = "Plum"
        case Plum80 = "Plum80"
        case Plum60 = "Plum60"
        case Plum40 = "Plum40"
        case Plum20 = "Plum20"
        case Seablue = "Seablue"
        case Seablue80 = "Seablue80"
        case Seablue60 = "Seablue60"
        case Seablue40 = "Seablue40"
        case Seablue20 = "Seablue20"
        case Black = "Black"
        case White = "White" 
        
    }
    
